# MCreator-1.16.5-Forge-Generator

Thanks to the MCreator team for maintaining it for so long! 

This Generator is built over the old official generator, but this one is NOT official, and is not being maintained by the MCreator Team. Do not bother them for any bugs when using this generator, instead report it in the issues tab, ty.
